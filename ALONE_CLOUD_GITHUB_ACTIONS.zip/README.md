# ALONE CLOUD — GitHub Actions Edition

This version starts the FastAPI service and Telegram polling bot together inside one GitHub Actions runner.

## Required GitHub Secrets
Repository → Settings → Secrets and variables → Actions → New repository secret:

- `AI_API_KEY`: key from your AI provider
- `TELEGRAM_BOT_TOKEN`: token from BotFather
- `DATABASE_URL`: external PostgreSQL URL, SQLAlchemy format, e.g. `postgresql+psycopg://USER:PASSWORD@HOST:5432/DBNAME`
- `ADMIN_API_KEY`: long random admin secret
- `CLOUD_API_KEY`: long random key used by the Telegram bot to call the API

Optional Repository Variables:
- `AI_BASE_URL`: default `https://api.openai.com/v1`
- `AI_MODEL`: default `gpt-4o-mini`

Never put real secrets in code, README, or committed `.env` files.

## Start
1. Upload all files to the root of your GitHub repository.
2. Add the five required secrets above.
3. Open Actions → ALONE CLOUD → Run workflow.
4. Watch the job logs. The API health check and Telegram bot start are shown there.

## Important limitations
GitHub-hosted runners are temporary. This workflow stops when the job ends and has a 350-minute timeout; it is not a 24/7 production host. The API listens only on `127.0.0.1` inside the runner, so it is intended for the Telegram bot in the same workflow and is not a public internet API endpoint. `DATABASE_URL` must point to an external, reachable PostgreSQL database. Do not use a localhost database URL.

For a public always-on API, deploy the same FastAPI app to a persistent host (VPS/container platform) and set the bot's `CLOUD_URL` to that public HTTPS URL.

## API
- `GET /health`
- `GET /v1/models` (Bearer `CLOUD_API_KEY`)
- `POST /v1/chat/completions` (Bearer `CLOUD_API_KEY`)
- Admin endpoints use `X-Admin-Key: ADMIN_API_KEY`.
- API docs while runner is active: `http://127.0.0.1:8000/docs` from inside the runner only.
